from pathlib import Path
from app.tools.doc_generator import DocumentGenerator

def main():
    generator = DocumentGenerator(root_dir=Path("./output"))

    # Generate a PDF report
    pdf_path = generator.generate_pdf(
        filepath="Sample_Report.pdf",
        title="Quarterly Review",
        subtitle="Confidential",
        sections=[{"heading": "Summary", "content": "All systems operating normally."}],
    )

    print(f"Generated PDF successfully at: {pdf_path}")

if __name__ == "__main__":
    main()
