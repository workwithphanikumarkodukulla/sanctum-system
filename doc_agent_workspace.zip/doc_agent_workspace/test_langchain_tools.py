"""Test invoking the LangChain @tool wrappers directly."""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.tools.doc_generator import DocumentGenerator
from app.tools.doc_tools import make_document_tools

def main():
    workspace = Path(__file__).parent / "output"
    gen = DocumentGenerator(root_dir=workspace)
    tools = make_document_tools(gen)
    tools_by_name = {t.name: t for t in tools}

    print(f"Loaded {len(tools)} LangChain tools:")
    for name in tools_by_name:
        print(f" - {name}")

    # Test invoking generate_structured_note via LangChain tool
    tool_fn = tools_by_name["generate_structured_note"]
    payload = {
        "filepath": "LangChain_Test_Note.md",
        "title": "Automated Tool Verification",
        "summary": "Verified that LangChain @tool wrappers execute reliably.",
        "tags_csv": "langchain, tools, automated-test",
        "sections_json": json.dumps([
            {
                "heading": "Test Results",
                "tasks": ["LangChain tool binding confirmed", "JSON parameter parsing confirmed"]
            }
        ])
    }
    result_str = tool_fn.invoke(payload)
    print("\nTool invocation result:")
    print(result_str)

    res = json.loads(result_str)
    assert res.get("status") == "success"
    assert Path(res.get("file")).exists()
    print("\n[SUCCESS] LangChain tool successfully generated file:", res.get("file"))

if __name__ == "__main__":
    main()
