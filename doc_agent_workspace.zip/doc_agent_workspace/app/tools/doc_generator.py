"""Professional Document Generation Engine.
Handles PDF, Word (DOCX), PowerPoint (PPTX), Excel (XLSX), and Markdown Notes.
"""

from __future__ import annotations

import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# -------------------------------------------------------------------------
# Theme & Palette Constants (Modern Executive Dark Slate & Royal Blue)
# -------------------------------------------------------------------------
COLOR_PRIMARY_HEX = "1E3A8A"      # Deep Navy Blue
COLOR_SECONDARY_HEX = "2563EB"    # Royal Blue Accent
COLOR_TEXT_MAIN_HEX = "0F172A"    # Slate 900
COLOR_TEXT_MUTED_HEX = "475569"   # Slate 600
COLOR_BG_LIGHT_HEX = "F8FAFC"     # Slate 50
COLOR_BORDER_HEX = "E2E8F0"       # Slate 200
COLOR_WHITE_HEX = "FFFFFF"


class DocumentGenerator:
    """Produces visually polished documents with executive corporate styling."""

    def __init__(self, root_dir: str | Path):
        self.root_dir = Path(root_dir).resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def _resolve_path(self, relative_path: str) -> Path:
        target = (self.root_dir / relative_path).resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        return target

    # =========================================================================
    # 1. EXCEL SPREADSHEETS (.xlsx)
    # =========================================================================
    def generate_excel(
        self,
        filepath: str,
        sheets: List[Dict[str, Any]]
    ) -> str:
        """Generates a professional Excel workbook with auto-fitted columns,
        styled headers, zebra-striping, and summary rows.
        """
        import openpyxl
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter

        target_file = self._resolve_path(filepath)
        wb = openpyxl.Workbook()
        wb.remove(wb.active)  # Remove default blank sheet

        header_fill = PatternFill(start_color=COLOR_PRIMARY_HEX, end_color=COLOR_PRIMARY_HEX, fill_type="solid")
        header_font = Font(name="Segoe UI", size=11, bold=True, color=COLOR_WHITE_HEX)

        zebra_fill = PatternFill(start_color=COLOR_BG_LIGHT_HEX, end_color=COLOR_BG_LIGHT_HEX, fill_type="solid")
        body_font = Font(name="Segoe UI", size=10, color=COLOR_TEXT_MAIN_HEX)
        total_font = Font(name="Segoe UI", size=10, bold=True, color=COLOR_TEXT_MAIN_HEX)

        thin_border = Border(
            left=Side(style="thin", color=COLOR_BORDER_HEX),
            right=Side(style="thin", color=COLOR_BORDER_HEX),
            top=Side(style="thin", color=COLOR_BORDER_HEX),
            bottom=Side(style="thin", color=COLOR_BORDER_HEX),
        )
        total_border = Border(
            top=Side(style="thin", color=COLOR_PRIMARY_HEX),
            bottom=Side(style="double", color=COLOR_PRIMARY_HEX),
        )

        for sheet_spec in sheets:
            ws = wb.create_sheet(title=sheet_spec.get("title", "Sheet")[:31])
            ws.views.sheetView[0].showGridLines = True

            headers = sheet_spec.get("headers", [])
            rows = sheet_spec.get("rows", [])
            totals = sheet_spec.get("totals_row")

            # 1. Headers
            ws.append(headers)
            for col_idx in range(1, len(headers) + 1):
                cell = ws.cell(row=1, column=col_idx)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center", vertical="center")
            ws.row_dimensions[1].height = 26

            # 2. Data Rows
            current_row = 2
            for r_idx, row_data in enumerate(rows):
                ws.append(row_data)
                is_even = (r_idx % 2 == 0)
                for col_idx in range(1, len(row_data) + 1):
                    cell = ws.cell(row=current_row, column=col_idx)
                    cell.font = body_font
                    cell.border = thin_border
                    if is_even:
                        cell.fill = zebra_fill

                    if isinstance(cell.value, (int, float)):
                        cell.alignment = Alignment(horizontal="right", vertical="center")
                        if isinstance(cell.value, float):
                            cell.number_format = "#,##0.00"
                    else:
                        cell.alignment = Alignment(horizontal="left", vertical="center")
                ws.row_dimensions[current_row].height = 20
                current_row += 1

            # 3. Totals Row
            if totals:
                ws.append(totals)
                for col_idx in range(1, len(totals) + 1):
                    cell = ws.cell(row=current_row, column=col_idx)
                    cell.font = total_font
                    cell.border = total_border
                    if isinstance(cell.value, (int, float)):
                        cell.alignment = Alignment(horizontal="right", vertical="center")
                        if isinstance(cell.value, float):
                            cell.number_format = "#,##0.00"
                ws.row_dimensions[current_row].height = 22

            # 4. Auto-fit column widths
            for col in ws.columns:
                max_len = 0
                col_letter = get_column_letter(col[0].column)
                for cell in col:
                    val_str = str(cell.value or "")
                    max_len = max(max_len, len(val_str))
                ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

        wb.save(target_file)
        return str(target_file)

    # =========================================================================
    # 2. PRESENTATIONS (.pptx)
    # =========================================================================
    def generate_presentation(
        self,
        filepath: str,
        title: str,
        subtitle: str,
        slides_data: List[Dict[str, Any]]
    ) -> str:
        """Generates modern 16:9 PowerPoint presentation with cards and styled typography."""
        from pptx import Presentation
        from pptx.dml.color import RGBColor
        from pptx.enum.shapes import MSO_SHAPE
        from pptx.util import Inches, Pt

        target_file = self._resolve_path(filepath)
        prs = Presentation()
        # 16:9 widescreen dimensions
        prs.slide_width = Inches(13.333)
        prs.slide_height = Inches(7.5)
        blank_slide_layout = prs.slide_layouts[6]

        primary_rgb = RGBColor.from_string(COLOR_PRIMARY_HEX)
        accent_rgb = RGBColor.from_string(COLOR_SECONDARY_HEX)
        text_dark = RGBColor.from_string(COLOR_TEXT_MAIN_HEX)
        bg_card_rgb = RGBColor.from_string(COLOR_BG_LIGHT_HEX)
        border_rgb = RGBColor.from_string(COLOR_BORDER_HEX)

        # Slide 1: Cover / Title Slide
        title_slide = prs.slides.add_slide(blank_slide_layout)
        bg = title_slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
        bg.fill.solid()
        bg.fill.fore_color.rgb = primary_rgb
        bg.line.fill.background()

        # Accent decorative bar
        bar = title_slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(1.0), Inches(2.0), Inches(0.15), Inches(3.2))
        bar.fill.solid()
        bar.fill.fore_color.rgb = accent_rgb
        bar.line.fill.background()

        tbox = title_slide.shapes.add_textbox(Inches(1.4), Inches(2.0), Inches(11.0), Inches(3.2))
        tf = tbox.text_frame
        tf.word_wrap = True

        p1 = tf.paragraphs[0]
        p1.text = title
        p1.font.name = "Arial"
        p1.font.size = Pt(42)
        p1.font.bold = True
        p1.font.color.rgb = RGBColor(255, 255, 255)

        if subtitle:
            p2 = tf.add_paragraph()
            p2.text = subtitle
            p2.font.name = "Arial"
            p2.font.size = Pt(20)
            p2.font.color.rgb = RGBColor(191, 219, 254)  # Soft Sky Blue
            p2.space_before = Pt(16)

        # Content Slides
        for s_data in slides_data:
            slide = prs.slides.add_slide(blank_slide_layout)

            # Header
            header_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.5), Inches(11.7), Inches(0.9))
            htf = header_box.text_frame
            hp = htf.paragraphs[0]
            hp.text = s_data.get("title", "Slide")
            hp.font.name = "Arial"
            hp.font.size = Pt(26)
            hp.font.bold = True
            hp.font.color.rgb = primary_rgb

            # Cards Layout
            cards = s_data.get("cards", [])
            if cards:
                num_cards = min(len(cards), 3)
                gap = Inches(0.3)
                total_w = Inches(11.7)
                card_width = (total_w - gap * (num_cards - 1)) / num_cards
                start_left = Inches(0.8)
                top_pos = Inches(1.8)
                card_height = Inches(4.8)

                for i, card in enumerate(cards[:num_cards]):
                    left_pos = start_left + i * (card_width + gap)
                    shape = slide.shapes.add_shape(
                        MSO_SHAPE.ROUNDED_RECTANGLE,
                        left_pos,
                        top_pos,
                        card_width,
                        card_height
                    )
                    shape.fill.solid()
                    shape.fill.fore_color.rgb = bg_card_rgb
                    shape.line.color.rgb = border_rgb
                    shape.line.width = Pt(1.5)

                    ctf = shape.text_frame
                    ctf.margin_left = Inches(0.3)
                    ctf.margin_right = Inches(0.3)
                    ctf.margin_top = Inches(0.3)
                    ctf.word_wrap = True

                    cp1 = ctf.paragraphs[0]
                    cp1.text = card.get("title", "")
                    cp1.font.name = "Arial"
                    cp1.font.bold = True
                    cp1.font.size = Pt(17)
                    cp1.font.color.rgb = primary_rgb

                    cp2 = ctf.add_paragraph()
                    cp2.text = card.get("text", "")
                    cp2.font.name = "Arial"
                    cp2.font.size = Pt(13)
                    cp2.font.color.rgb = text_dark
                    cp2.space_before = Pt(12)

            # Bullet points layout
            bullets = s_data.get("bullet_points", [])
            if bullets and not cards:
                box = slide.shapes.add_textbox(Inches(0.8), Inches(1.8), Inches(11.7), Inches(4.8))
                btf = box.text_frame
                btf.word_wrap = True
                for b_idx, bullet in enumerate(bullets):
                    bp = btf.paragraphs[0] if b_idx == 0 else btf.add_paragraph()
                    bp.text = f"•   {bullet}"
                    bp.font.name = "Arial"
                    bp.font.size = Pt(18)
                    bp.font.color.rgb = text_dark
                    bp.space_before = Pt(16)

        prs.save(target_file)
        return str(target_file)

    # =========================================================================
    # 3. WORD DOCUMENTS (.docx)
    # =========================================================================
    def generate_docx(
        self,
        filepath: str,
        title: str,
        subtitle: str,
        sections: List[Dict[str, Any]]
    ) -> str:
        """Generates executive Word documents with custom typography,
        styled tables, callout blocks, and headers.
        """
        import docx
        from docx.enum.table import WD_TABLE_ALIGNMENT
        from docx.oxml import parse_xml
        from docx.oxml.ns import nsdecls
        from docx.shared import Inches, Pt, RGBColor

        target_file = self._resolve_path(filepath)
        doc = docx.Document()

        # 1-inch Margins
        for section in doc.sections:
            section.top_margin = Inches(1.0)
            section.bottom_margin = Inches(1.0)
            section.left_margin = Inches(1.0)
            section.right_margin = Inches(1.0)

        # Title
        p_title = doc.add_paragraph()
        r_title = p_title.add_run(title)
        r_title.font.name = "Arial"
        r_title.font.size = Pt(26)
        r_title.font.bold = True
        r_title.font.color.rgb = RGBColor.from_string(COLOR_PRIMARY_HEX)
        p_title.paragraph_format.space_after = Pt(2)

        # Subtitle
        if subtitle:
            p_sub = doc.add_paragraph()
            r_sub = p_sub.add_run(subtitle)
            r_sub.font.name = "Arial"
            r_sub.font.size = Pt(13)
            r_sub.font.italic = True
            r_sub.font.color.rgb = RGBColor.from_string(COLOR_TEXT_MUTED_HEX)
            p_sub.paragraph_format.space_after = Pt(22)

        for sec in sections:
            heading = sec.get("heading")
            if heading:
                h = doc.add_paragraph()
                hr = h.add_run(heading)
                hr.font.name = "Arial"
                hr.font.size = Pt(16)
                hr.font.bold = True
                hr.font.color.rgb = RGBColor.from_string(COLOR_PRIMARY_HEX)
                h.paragraph_format.space_before = Pt(14)
                h.paragraph_format.space_after = Pt(6)

            content = sec.get("content")
            if content:
                p = doc.add_paragraph()
                pr = p.add_run(content)
                pr.font.name = "Calibri"
                pr.font.size = Pt(11)
                pr.font.color.rgb = RGBColor.from_string(COLOR_TEXT_MAIN_HEX)
                p.paragraph_format.space_after = Pt(8)
                p.paragraph_format.line_spacing = 1.15

            # Callout Box
            callout = sec.get("callout")
            if callout:
                tbl = doc.add_table(rows=1, cols=1)
                tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
                cell = tbl.cell(0, 0)
                cell.width = Inches(6.5)
                shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{COLOR_BG_LIGHT_HEX}"/>')
                cell._tc.get_or_add_tcPr().append(shd)

                cp = cell.paragraphs[0]
                cp.paragraph_format.left_indent = Inches(0.15)
                c_run = cp.add_run(f"📌  {callout}")
                c_run.font.name = "Calibri"
                c_run.font.size = Pt(10.5)
                c_run.font.bold = True
                c_run.font.color.rgb = RGBColor.from_string(COLOR_PRIMARY_HEX)
                doc.add_paragraph()

            # Table
            table_data = sec.get("table")
            if table_data:
                headers = table_data.get("headers", [])
                rows = table_data.get("rows", [])
                if headers:
                    t = doc.add_table(rows=len(rows) + 1, cols=len(headers))
                    t.alignment = WD_TABLE_ALIGNMENT.CENTER

                    # Header Row
                    for col_idx, h_text in enumerate(headers):
                        cell = t.cell(0, col_idx)
                        shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{COLOR_PRIMARY_HEX}"/>')
                        cell._tc.get_or_add_tcPr().append(shd)
                        p = cell.paragraphs[0]
                        r = p.add_run(h_text)
                        r.font.bold = True
                        r.font.color.rgb = RGBColor(255, 255, 255)
                        r.font.size = Pt(10)

                    # Data Rows
                    for r_idx, row in enumerate(rows):
                        is_even = (r_idx % 2 == 0)
                        for col_idx, val in enumerate(row):
                            cell = t.cell(r_idx + 1, col_idx)
                            if is_even:
                                shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{COLOR_BG_LIGHT_HEX}"/>')
                                cell._tc.get_or_add_tcPr().append(shd)
                            p = cell.paragraphs[0]
                            r = p.add_run(str(val))
                            r.font.size = Pt(9.5)

                    doc.add_paragraph()

        doc.save(target_file)
        return str(target_file)

    # =========================================================================
    # 4. PDF DOCUMENTS (.pdf)
    # =========================================================================
    def generate_pdf(
        self,
        filepath: str,
        title: str,
        subtitle: str,
        sections: List[Dict[str, Any]]
    ) -> str:
        """Generates executive PDF reports via ReportLab with running headers,
        page numbers ('Page X of Y'), tables, and callouts.
        """
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.pdfgen import canvas
        from reportlab.platypus import HRFlowable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

        target_file = self._resolve_path(filepath)

        class NumberedCanvas(canvas.Canvas):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self._saved_page_states = []

            def showPage(self):
                self._saved_page_states.append(dict(self.__dict__))
                self._startPage()

            def save(self):
                num_pages = len(self._saved_page_states)
                for state in self._saved_page_states:
                    self.__dict__.update(state)
                    self.draw_page_decorations(num_pages)
                    super().showPage()
                super().save()

            def draw_page_decorations(self, page_count):
                self.saveState()
                self.setFont("Helvetica", 9)
                self.setFillColor(colors.HexColor(f"#{COLOR_TEXT_MUTED_HEX}"))

                # Header (Pages > 1)
                if self._pageNumber > 1:
                    self.drawString(54, 750, title)
                    self.setStrokeColor(colors.HexColor(f"#{COLOR_BORDER_HEX}"))
                    self.setLineWidth(0.5)
                    self.line(54, 742, 558, 742)

                # Footer
                page_str = f"Page {self._pageNumber} of {page_count}"
                self.drawRightString(558, 40, page_str)
                self.drawString(54, 40, "Confidential & Proprietary")
                self.restoreState()

        doc = SimpleDocTemplate(
            str(target_file),
            pagesize=letter,
            leftMargin=54,
            rightMargin=54,
            topMargin=54,
            bottomMargin=54
        )

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "DocTitle",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=24,
            leading=28,
            textColor=colors.HexColor(f"#{COLOR_PRIMARY_HEX}"),
            spaceAfter=4
        )
        subtitle_style = ParagraphStyle(
            "DocSubTitle",
            parent=styles["Normal"],
            fontName="Helvetica-Oblique",
            fontSize=12,
            leading=16,
            textColor=colors.HexColor(f"#{COLOR_TEXT_MUTED_HEX}"),
            spaceAfter=14
        )
        heading_style = ParagraphStyle(
            "DocHeading",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=13,
            leading=17,
            textColor=colors.HexColor(f"#{COLOR_PRIMARY_HEX}"),
            spaceBefore=14,
            spaceAfter=6
        )
        body_style = ParagraphStyle(
            "DocBody",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=10,
            leading=14,
            textColor=colors.HexColor(f"#{COLOR_TEXT_MAIN_HEX}"),
            spaceAfter=8
        )
        callout_style = ParagraphStyle(
            "DocCallout",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=9.5,
            leading=13,
            textColor=colors.HexColor(f"#{COLOR_PRIMARY_HEX}")
        )

        story = []
        story.append(Paragraph(title, title_style))
        if subtitle:
            story.append(Paragraph(subtitle, subtitle_style))
        story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor(f"#{COLOR_PRIMARY_HEX}"), spaceAfter=14))

        for sec in sections:
            if "heading" in sec:
                story.append(Paragraph(sec["heading"], heading_style))
            if "content" in sec:
                story.append(Paragraph(sec["content"], body_style))

            # Callout
            if "callout" in sec:
                callout_p = Paragraph(f"💡 {sec['callout']}", callout_style)
                callout_table = Table([[callout_p]], colWidths=[504])
                callout_table.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(f"#{COLOR_BG_LIGHT_HEX}")),
                    ("BOX", (0, 0), (-1, -1), 1, colors.HexColor(f"#{COLOR_SECONDARY_HEX}")),
                    ("TOPPADDING", (0, 0), (-1, -1), 8),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                    ("LEFTPADDING", (0, 0), (-1, -1), 12),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 12),
                ]))
                story.append(callout_table)
                story.append(Spacer(1, 10))

            # Table
            if "table" in sec:
                headers = sec["table"].get("headers", [])
                rows = sec["table"].get("rows", [])
                if headers:
                    table_data = [[Paragraph(f"<b>{h}</b>", ParagraphStyle("TH", textColor=colors.white, fontName="Helvetica-Bold", fontSize=9)) for h in headers]]
                    for row in rows:
                        table_data.append([Paragraph(str(item), ParagraphStyle("TD", fontSize=8.5, leading=11)) for item in row])

                    col_w = 504 / len(headers)
                    t = Table(table_data, colWidths=[col_w] * len(headers))
                    t.setStyle(TableStyle([
                        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(f"#{COLOR_PRIMARY_HEX}")),
                        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor(f"#{COLOR_BG_LIGHT_HEX}")]),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor(f"#{COLOR_BORDER_HEX}")),
                        ("TOPPADDING", (0, 0), (-1, -1), 5),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                    ]))
                    story.append(t)
                    story.append(Spacer(1, 12))

        doc.build(story, canvasmaker=NumberedCanvas)
        return str(target_file)

    # =========================================================================
    # 5. STRUCTURED NOTES (.md)
    # =========================================================================
    def generate_note(
        self,
        filepath: str,
        title: str,
        tags: List[str],
        summary: str,
        sections: List[Dict[str, Any]]
    ) -> str:
        """Generates a professional Markdown note formatted with YAML frontmatter,
        summary callouts, checkboxes, and clean headings.
        """
        target_file = self._resolve_path(filepath)

        tag_list = ", ".join([f'"{t}"' for t in tags])
        today = datetime.date.today().isoformat()

        md = [
            "---",
            f'title: "{title}"',
            f"date: {today}",
            f"tags: [{tag_list}]",
            "---",
            "",
            f"# {title}",
            "",
            "> [!NOTE]",
            f"> **Executive Summary**: {summary}",
            "",
            "---",
            ""
        ]

        for sec in sections:
            h = sec.get("heading")
            if h:
                md.append(f"## {h}\n")
            if sec.get("content"):
                md.append(f"{sec['content']}\n")
            if sec.get("tasks"):
                for task in sec["tasks"]:
                    md.append(f"- [ ] {task}")
                md.append("")
            if sec.get("bullets"):
                for b in sec["bullets"]:
                    md.append(f"- {b}")
                md.append("")

        target_file.write_text("\n".join(md), encoding="utf-8")
        return str(target_file)
