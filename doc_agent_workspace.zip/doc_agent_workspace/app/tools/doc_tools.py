"""LangChain tool wrappers for professional document generation.
Integrates with LangChain agent architectures.
"""

from __future__ import annotations

import json
from langchain_core.tools import tool
from app.tools.doc_generator import DocumentGenerator


def make_document_tools(doc_generator: DocumentGenerator):
    """Creates LangChain tools for generating Excel, PPTX, Word, PDF, and Notes."""

    @tool
    def generate_excel_sheet(filepath: str, sheets_json: str) -> str:
        """Create a styled Excel spreadsheet (.xlsx) with auto-column sizing,
        colored headers, zebra-striping, and totals.
        `filepath`: Path for output, e.g. 'reports/financial_summary.xlsx'
        `sheets_json`: JSON string representing a list of sheets:
        [
          {
            "title": "Q1 Performance",
            "headers": ["Product", "Units Sold", "Revenue ($)"],
            "rows": [["Widget A", 100, 2500.0], ["Widget B", 50, 1500.0]],
            "totals_row": ["Total", 150, 4000.0]
          }
        ]
        """
        try:
            sheets = json.loads(sheets_json)
            path = doc_generator.generate_excel(filepath, sheets)
            return json.dumps({"status": "success", "file": path, "format": "xlsx"})
        except Exception as e:
            return json.dumps({"status": "error", "error": f"Failed to create Excel: {str(e)}"})

    @tool
    def generate_presentation(filepath: str, title: str, subtitle: str, slides_json: str) -> str:
        """Create a modern 16:9 widescreen PowerPoint presentation (.pptx)
        with cards, title slide, and key takeaways.
        `filepath`: Path for output, e.g. 'pitch/deck.pptx'
        `title`: Presentation main title
        `subtitle`: Subtitle or presenter information
        `slides_json`: JSON string representing slides:
        [
          {
            "title": "Core Architecture",
            "cards": [
              {"title": "Agentic Core", "text": "LangChain ReAct orchestration."},
              {"title": "Local Inference", "text": "Hardware-accelerated private execution."}
            ]
          },
          {
            "title": "Key Accomplishments",
            "bullet_points": ["Sub-second latency achieved", "100% offline data privacy"]
          }
        ]
        """
        try:
            slides = json.loads(slides_json)
            path = doc_generator.generate_presentation(filepath, title, subtitle, slides)
            return json.dumps({"status": "success", "file": path, "format": "pptx"})
        except Exception as e:
            return json.dumps({"status": "error", "error": f"Failed to create Presentation: {str(e)}"})

    @tool
    def generate_word_document(filepath: str, title: str, subtitle: str, sections_json: str) -> str:
        """Create an executive Word document (.docx) with custom palettes,
        callout boxes, and formatted data tables.
        `filepath`: Path for output, e.g. 'docs/System_Report.docx'
        `title`: Document title
        `subtitle`: Subtitle / document version
        `sections_json`: JSON string list of sections:
        [
          {
            "heading": "1. Executive Summary",
            "content": "Comprehensive report on system architecture...",
            "callout": "This platform operates entirely on premise.",
            "table": {
              "headers": ["Service", "Port", "Protocol"],
              "rows": [["API Gateway", "8000", "HTTP"], ["Database", "5432", "TCP"]]
            }
          }
        ]
        """
        try:
            sections = json.loads(sections_json)
            path = doc_generator.generate_docx(filepath, title, subtitle, sections)
            return json.dumps({"status": "success", "file": path, "format": "docx"})
        except Exception as e:
            return json.dumps({"status": "error", "error": f"Failed to create Word document: {str(e)}"})

    @tool
    def generate_pdf_report(filepath: str, title: str, subtitle: str, sections_json: str) -> str:
        """Create an executive PDF report with page numbers ('Page X of Y'),
        corporate header, styled tables, and highlighted callouts.
        `filepath`: Path for output, e.g. 'reports/Audit_Report.pdf'
        `title`: Report title
        `subtitle`: Subtitle or organization name
        `sections_json`: JSON string list of sections:
        [
          {
            "heading": "Audit Findings",
            "content": "All compliance benchmarks evaluated across all endpoints.",
            "callout": "Certified ISO-27001 readiness.",
            "table": {
              "headers": ["Control ID", "Scope", "Status"],
              "rows": [["AC-1", "Access Control Policy", "Compliant"], ["IA-2", "Multi-Factor Authentication", "Compliant"]]
            }
          }
        ]
        """
        try:
            sections = json.loads(sections_json)
            path = doc_generator.generate_pdf(filepath, title, subtitle, sections)
            return json.dumps({"status": "success", "file": path, "format": "pdf"})
        except Exception as e:
            return json.dumps({"status": "error", "error": f"Failed to create PDF: {str(e)}"})

    @tool
    def generate_structured_note(filepath: str, title: str, summary: str, tags_csv: str, sections_json: str) -> str:
        """Create a Markdown note (.md) with YAML frontmatter, summary box,
        checkboxes, and sections.
        `filepath`: Path for output, e.g. 'notes/meeting_notes.md'
        `title`: Title of the note
        `summary`: Executive summary text
        `tags_csv`: Comma-separated tags, e.g. 'planning, ai, sprint'
        `sections_json`: JSON string list of sections:
        [
          {
            "heading": "Action Items",
            "tasks": ["Finalize API endpoints", "Review test coverage"],
            "bullets": ["Deadline: End of Week", "Lead: Dev Team"]
          }
        ]
        """
        try:
            tags = [t.strip() for t in tags_csv.split(",") if t.strip()]
            sections = json.loads(sections_json)
            path = doc_generator.generate_note(filepath, title, tags, summary, sections)
            return json.dumps({"status": "success", "file": path, "format": "md"})
        except Exception as e:
            return json.dumps({"status": "error", "error": f"Failed to create Note: {str(e)}"})

    return [
        generate_excel_sheet,
        generate_presentation,
        generate_word_document,
        generate_pdf_report,
        generate_structured_note,
    ]
