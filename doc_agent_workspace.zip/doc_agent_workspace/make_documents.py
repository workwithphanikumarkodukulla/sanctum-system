"""Simple, clear script to generate PDF, PPTX, DOCX, XLSX, and Markdown notes."""

from pathlib import Path
from app.tools.doc_generator import DocumentGenerator

# Initialize the generator. Set root_dir to where you want files saved.
# Use Path(".") for current folder, or Path("./output") for an output folder.
doc = DocumentGenerator(root_dir=Path("./output"))


# ==============================================================================
# 1. GENERATE PDF (.pdf)
# ==============================================================================
def create_pdf():
    pdf_path = doc.generate_pdf(
        filepath="my_report.pdf",
        title="Project Status Report",
        subtitle="Confidential — For Internal Review",
        sections=[
            {
                "heading": "1. Executive Summary",
                "content": "All milestones for Q3 are on track with zero blocking issues.",
                "callout": "Key highlight: Migration completed 2 weeks ahead of schedule."
            },
            {
                "heading": "2. Performance Metrics",
                "table": {
                    "headers": ["Metric", "Target", "Actual", "Status"],
                    "rows": [
                        ["API Latency", "< 50ms", "38ms", "Passed"],
                        ["Uptime", "99.9%", "99.98%", "Passed"],
                        ["Test Coverage", "> 85%", "91%", "Passed"],
                    ]
                }
            }
        ]
    )
    print(f"[PDF] Created: {pdf_path}")
    return pdf_path


# ==============================================================================
# 2. GENERATE POWERPOINT PRESENTATION (.pptx)
# ==============================================================================
def create_pptx():
    pptx_path = doc.generate_presentation(
        filepath="my_deck.pptx",
        title="Q3 Strategy Review",
        subtitle="Engineering & Product Roadmap",
        slides_data=[
            {
                "title": "Core Strategic Pillars",
                "cards": [
                    {"title": "Automation", "text": "End-to-end autonomous document pipelines."},
                    {"title": "Reliability", "text": "Fault-tolerant architecture with automated retries."},
                    {"title": "Security", "text": "Isolated workspace sandboxing and strict access controls."}
                ]
            },
            {
                "title": "Key Accomplishments",
                "bullet_points": [
                    "Shipped new document generator for PDF, Word, PowerPoint, and Excel.",
                    "Improved overall test suite coverage to 91%.",
                    "Onboarded 5 enterprise pilot customers."
                ]
            }
        ]
    )
    print(f"[PPTX] Created: {pptx_path}")
    return pptx_path


# ==============================================================================
# 3. GENERATE WORD DOCUMENT (.docx)
# ==============================================================================
def create_word():
    docx_path = doc.generate_docx(
        filepath="my_document.docx",
        title="Software Design Specification",
        subtitle="System Architecture & Guidelines",
        sections=[
            {
                "heading": "Overview",
                "content": "This specification outlines the components of the document generation engine.",
                "callout": "Approved by Architecture Board on September 2026."
            },
            {
                "heading": "Component Breakdown",
                "content": "The following table details the core modules:",
                "table": {
                    "headers": ["Module", "Format", "Library Used"],
                    "rows": [
                        ["PDF Builder", ".pdf", "ReportLab"],
                        ["Slide Builder", ".pptx", "python-pptx"],
                        ["Doc Builder", ".docx", "python-docx"],
                        ["Sheet Builder", ".xlsx", "openpyxl"]
                    ]
                }
            }
        ]
    )
    print(f"[DOCX] Created: {docx_path}")
    return docx_path


# ==============================================================================
# 4. GENERATE EXCEL SPREADSHEET (.xlsx)
# ==============================================================================
def create_excel():
    excel_path = doc.generate_excel(
        filepath="my_financials.xlsx",
        sheets=[
            {
                "title": "Sales Revenue",
                "headers": ["Region", "Units Sold", "Price ($)", "Total Revenue ($)"],
                "rows": [
                    ["North America", 450, 120.00, 54000.00],
                    ["Europe", 320, 125.00, 40000.00],
                    ["Asia Pacific", 510, 115.00, 58650.00]
                ],
                "totals_row": ["Grand Total", 1280, "", 152650.00]
            }
        ]
    )
    print(f"[XLSX] Created: {excel_path}")
    return excel_path


# ==============================================================================
# 5. GENERATE STRUCTURED NOTE / MARKDOWN (.md)
# ==============================================================================
def create_note():
    note_path = doc.generate_note(
        filepath="my_notes.md",
        title="Weekly Engineering Notes",
        tags=["engineering", "weekly", "release"],
        summary="Summary of work completed and action items for next sprint.",
        sections=[
            {
                "heading": "Action Items",
                "tasks": [
                    "Complete integration tests",
                    "Update developer documentation",
                    "Deploy staging environment"
                ]
            },
            {
                "heading": "Key Takeaways",
                "bullets": [
                    "Performance increased by 25%",
                    "Zero downtime during deployment"
                ]
            }
        ]
    )
    print(f"[NOTE] Created: {note_path}")
    return note_path


if __name__ == "__main__":
    print("Generating all 5 document types...\n")
    create_pdf()
    create_pptx()
    create_word()
    create_excel()
    create_note()
    print("\nAll documents generated successfully!")
