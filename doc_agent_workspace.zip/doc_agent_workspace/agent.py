"""Agent logic — LLM-driven tool calling with document generation support."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from langchain_core.messages import (
    AIMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.tools import tool

from app.tools.doc_generator import DocumentGenerator
from app.tools.doc_tools import make_document_tools


def _make_langchain_tools(tool_manager):
    """LangChain wrappers for standard workspace and system operations."""

    @tool
    def create_file(path: str, content: str = "") -> str:
        """Create a new file in the workspace with given path and content."""
        try:
            result = tool_manager.execute("file", action="create_file", path=path, content=content)
            return json.dumps(result)
        except Exception as e:
            return json.dumps({"error": str(e)})

    @tool
    def read_file(path: str) -> str:
        """Read and return full contents of a file in the workspace."""
        try:
            result = tool_manager.execute("file", action="read_file", path=path)
            return json.dumps(result)
        except Exception as e:
            return json.dumps({"error": str(e)})

    @tool
    def write_file(path: str, content: str) -> str:
        """Write (overwrite) content to a file in the workspace."""
        try:
            result = tool_manager.execute("file", action="write_file", path=path, content=content)
            return json.dumps(result)
        except Exception as e:
            return json.dumps({"error": str(e)})

    @tool
    def list_files(path: str = ".", recursive: bool = False) -> str:
        """List files and folders in the workspace directory."""
        try:
            result = tool_manager.execute("workspace", action="list_files", path=path, recursive=recursive)
            return json.dumps(result)
        except Exception as e:
            return json.dumps({"error": str(e)})

    return [create_file, read_file, write_file, list_files]


class CodingAgent:
    """Agentic assistant that uses LLM tool-calling to interact with the workspace
    and generate professional corporate documents."""

    MAX_TOOL_ITERATIONS = 6

    def __init__(self, llm_manager, tool_manager=None, workspace_dir: str = "."):
        self.llm_manager = llm_manager
        self.tool_manager = tool_manager
        self.workspace_dir = Path(workspace_dir).resolve()

        # 1. Initialize professional document engine
        self.doc_generator = DocumentGenerator(root_dir=self.workspace_dir)

        # 2. Assemble tool suite (Core workspace tools + Document generation tools)
        core_tools = _make_langchain_tools(self.tool_manager) if self.tool_manager else []
        doc_tools = make_document_tools(self.doc_generator)
        self.lc_tools = core_tools + doc_tools

        self._tools_by_name = {t.name: t for t in self.lc_tools}
        if hasattr(self.llm_manager, "_llm") and self.llm_manager._llm:
            self.llm_with_tools = self.llm_manager._llm.bind_tools(
                self.lc_tools, tool_choice="auto"
            )

    def list_tools(self) -> list[dict[str, str]]:
        """Return the list of available tools with name and description."""
        return [
            {"name": t.name, "description": t.description}
            for t in self.lc_tools
        ]
