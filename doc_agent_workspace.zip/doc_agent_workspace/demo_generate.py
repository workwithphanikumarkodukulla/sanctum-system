"""Demonstration script: Generates all 5 professional document formats
using the DocumentGenerator and verifies the generated files.
"""

import os
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent))

from app.tools.doc_generator import DocumentGenerator


def main():
    workspace = Path(__file__).parent / "output"
    workspace.mkdir(parents=True, exist_ok=True)
    
    print(f"[*] Initializing DocumentGenerator with workspace: {workspace}")
    gen = DocumentGenerator(root_dir=workspace)

    generated_files = []

    # 1. Professional Excel Spreadsheet (.xlsx)
    print("\n--- 1. Generating Styled Excel Workbook (.xlsx) ---")
    excel_path = gen.generate_excel(
        filepath="Executive_Financial_Summary.xlsx",
        sheets=[
            {
                "title": "Regional Revenue",
                "headers": ["Region", "Lead Executive", "Deals Closed", "Revenue ($)", "Growth (%)"],
                "rows": [
                    ["North America", "Sarah Jenkins", 142, 1420500.00, 18.4],
                    ["Europe / EMEA", "Marcus Vance", 118, 1180250.50, 12.1],
                    ["Asia-Pacific", "Kenji Sato", 165, 1895000.00, 24.8],
                    ["Latin America", "Elena Gomez", 74, 592000.00, 9.5],
                ],
                "totals_row": ["Consolidated Total", "", 499, 5087750.50, ""]
            },
            {
                "title": "Expense Breakdown",
                "headers": ["Category", "Budget ($)", "Actual ($)", "Variance ($)"],
                "rows": [
                    ["R&D & Engineering", 1200000.00, 1145000.00, -55000.00],
                    ["Cloud Infrastructure", 450000.00, 478000.00, 28000.00],
                    ["Sales & Marketing", 600000.00, 582000.00, -18000.00],
                    ["Operations & Legal", 250000.00, 240000.00, -10000.00],
                ],
                "totals_row": ["Total Operating Expenses", 2500000.00, 2445000.00, -55000.00]
            }
        ]
    )
    print(f"[+] Created Excel: {excel_path} (Size: {os.path.getsize(excel_path)} bytes)")
    generated_files.append(excel_path)

    # 2. Modern 16:9 Presentation (.pptx)
    print("\n--- 2. Generating 16:9 PowerPoint Presentation (.pptx) ---")
    pptx_path = gen.generate_presentation(
        filepath="Enterprise_AI_Strategy.pptx",
        title="Next-Gen Agentic Architecture",
        subtitle="Confidential Strategic Deck | Enterprise LLM Deployment",
        slides_data=[
            {
                "title": "Core Technical Pillars",
                "cards": [
                    {
                        "title": "Local Inference",
                        "text": "Ultra-low latency inference with zero external network leakage and full data privacy."
                    },
                    {
                        "title": "Agentic Tooling",
                        "text": "Automated document compilation, file management, and terminal automation via ReAct loops."
                    },
                    {
                        "title": "Security & Sandbox",
                        "text": "Workspace-confined execution boundaries with audit-ready traceability."
                    }
                ]
            },
            {
                "title": "Key Accomplishments & Roadmaps",
                "bullet_points": [
                    "Engineered end-to-end multi-format generation (PDF, DOCX, PPTX, XLSX, MD).",
                    "Integrated automated styling palettes compliant with enterprise visual guidelines.",
                    "Achieved sub-second document compilation across all flowable structures.",
                    "Rollout planned across 12 distributed engineering teams in Q4."
                ]
            }
        ]
    )
    print(f"[+] Created Presentation: {pptx_path} (Size: {os.path.getsize(pptx_path)} bytes)")
    generated_files.append(pptx_path)

    # 3. Executive Word Document (.docx)
    print("\n--- 3. Generating Styled Word Document (.docx) ---")
    docx_path = gen.generate_docx(
        filepath="System_Architecture_Whitepaper.docx",
        title="Autonomous Agent Systems: Technical Whitepaper",
        subtitle="Version 2.4 | DeepMind & Enterprise Architecture Standards",
        sections=[
            {
                "heading": "1. Executive Summary",
                "content": (
                    "Modern enterprise applications demand intelligent agentic architectures capable of "
                    "multi-modal document creation, deterministic code execution, and autonomous decision loops. "
                    "This whitepaper establishes the deployment blueprints and production benchmarks."
                ),
                "callout": "Guaranteed 99.99% reproducibility across all runtime operating systems."
            },
            {
                "heading": "2. Benchmark & Throughput Metrics",
                "content": "The following performance specifications were captured across 50,000 synthetic operations:",
                "table": {
                    "headers": ["Component", "Throughput (ops/s)", "P99 Latency (ms)", "Status"],
                    "rows": [
                        ["PDF Engine", "1,240", "42 ms", "Production Ready"],
                        ["Excel Formatter", "3,890", "15 ms", "Production Ready"],
                        ["PowerPoint Builder", "820", "68 ms", "Production Ready"],
                        ["Word Styler", "2,150", "28 ms", "Production Ready"],
                    ]
                }
            },
            {
                "heading": "3. Security & Boundary Isolation",
                "content": (
                    "All path manipulations utilize strict path resolution to prevent directory traversal "
                    "vulnerabilities, confining all output generation to specified workspace scopes."
                )
            }
        ]
    )
    print(f"[+] Created Word Document: {docx_path} (Size: {os.path.getsize(docx_path)} bytes)")
    generated_files.append(docx_path)

    # 4. Executive PDF Report (.pdf)
    print("\n--- 4. Generating Executive PDF Report (.pdf) ---")
    pdf_path = gen.generate_pdf(
        filepath="Security_Audit_Report.pdf",
        title="Enterprise Compliance & Security Audit",
        subtitle="Annual Infrastructure Review | ISO-27001 & SOC-2 Type II",
        sections=[
            {
                "heading": "1. Scope of Audit & Overview",
                "content": (
                    "This document summarizes the comprehensive vulnerability assessment, tool authorization, "
                    "and data isolation mechanisms enforced throughout the agentic workspace. All penetration tests "
                    "and dynamic checks concluded with zero critical or high-severity vulnerabilities."
                ),
                "callout": "Certified Level-3 Compliance: Zero external data leaks detected during 48-hour continuous stress test."
            },
            {
                "heading": "2. Security Control Assessment Matrix",
                "table": {
                    "headers": ["Control Domain", "Reference Standard", "Test Method", "Result"],
                    "rows": [
                        ["Access Control", "ISO/IEC 27001:A.9", "Role-Based Token Verification", "Compliant"],
                        ["Cryptography", "NIST SP 800-175B", "AES-256 GCM at Rest", "Compliant"],
                        ["Workspace Sandboxing", "CIS Benchmark 1.4", "Automated Path Confinement", "Compliant"],
                        ["Audit Logging", "SOC-2 CC6.8", "Immutable JSONL Tracing", "Compliant"],
                    ]
                }
            },
            {
                "heading": "3. Final Recommendation & Sign-Off",
                "content": (
                    "The agentic toolchain demonstrates industry-leading containment and adheres to all corporate governance "
                    "guidelines. Recommended for immediate enterprise rollout."
                )
            }
        ]
    )
    print(f"[+] Created PDF Report: {pdf_path} (Size: {os.path.getsize(pdf_path)} bytes)")
    generated_files.append(pdf_path)

    # 5. Structured Note (.md)
    print("\n--- 5. Generating Structured Note (.md) ---")
    note_path = gen.generate_note(
        filepath="Sprint_Architecture_Notes.md",
        title="Sprint 32: Document Engine Release Notes",
        tags=["architecture", "documents", "sprint-32", "production"],
        summary="Successfully implemented and validated high-fidelity document generation across PDF, Word, PowerPoint, Excel, and Markdown.",
        sections=[
            {
                "heading": "Completed Deliverables",
                "tasks": [
                    "Constructed DocumentGenerator with deep navy & royal blue executive palette",
                    "Enabled 16:9 widescreen PowerPoint cards layout",
                    "Added openpyxl auto-column fitting and double-underline totals",
                    "Integrated ReportLab NumberedCanvas for 'Page X of Y' pagination",
                    "Wrapped generator as LangChain-compatible @tool functions"
                ]
            },
            {
                "heading": "Immediate Next Steps",
                "bullets": [
                    "Provide workspace path and verification commands to developer.",
                    "Verify file formats open smoothly in respective desktop applications."
                ]
            }
        ]
    )
    print(f"[+] Created Markdown Note: {note_path} (Size: {os.path.getsize(note_path)} bytes)")
    generated_files.append(note_path)

    print("\n" + "=" * 60)
    print("ALL 5 PROFESSIONAL DOCUMENTS GENERATED SUCCESSFULLY!")
    print("=" * 60)
    for p in generated_files:
        print(f" -> {p}")

if __name__ == "__main__":
    main()
